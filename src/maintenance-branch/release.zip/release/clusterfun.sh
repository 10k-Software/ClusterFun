#!/bin/bash

java -Xms64m -Xmx612m -Djava.library.path=./lib/native/linux/ -jar ClusterFun.jar